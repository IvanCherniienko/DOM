const persons = document.querySelector('.persons')
const child = document.querySelector('.child')
const petro = document.getElementById('petro')

console.log(persons, child, petro)